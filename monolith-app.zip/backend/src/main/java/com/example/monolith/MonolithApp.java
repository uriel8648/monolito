package com.example.monolith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonolithApp {
    public static void main(String[] args) {
        SpringApplication.run(MonolithApp.class, args);
    }
}
